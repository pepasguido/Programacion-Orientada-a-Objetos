﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_clase_4
{
   public abstract class Persona
    {
        private string nombre;
        private string apellido;
        private string dni;
        private int pasosRecorridos;

        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Dni { get => dni; set => dni = value; }
        public int PasosRecorridos { get => pasosRecorridos; set => pasosRecorridos = value; }

        public abstract void saludar();

        public void caminar(int pasos)
        {
            PasosRecorridos = PasosRecorridos + pasos;
        }

        public void correr(int pasos)
        {
            PasosRecorridos = PasosRecorridos + pasos *2;
        }

        public void hacerEjercicio(int pasos)
        {
            PasosRecorridos = PasosRecorridos + pasos * 3;
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_clase_4
{
    public partial class Form1 : Form
    {
        private Empleado miEmpleado = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            miEmpleado = new Empleado(Convert.ToDouble(txtSueldo.Text));
            miEmpleado.Nombre = txtNombre.Text;
            miEmpleado.Apellido = txtApellido.Text;
            miEmpleado.Dni = txtDNI.Text;

            cambiarLabels();
        }

        private void asignar_Click(object sender, EventArgs e)
        {
            miEmpleado.Bono = Convert.ToDouble(txtBono.Text);
            cambiarLabels();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            miEmpleado.calificar(txtCalificacion.Text);
            cambiarLabels();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            miEmpleado.caminar(Convert.ToInt32( txtPasos.Text));
            cambiarLabels();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            miEmpleado.correr(Convert.ToInt32(txtPasos.Text));
            cambiarLabels();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            miEmpleado.hacerEjercicio(Convert.ToInt32(txtPasos.Text));
            cambiarLabels();

        }

        private void cambiarLabels()
        {
            lblSeuldoB.Text = miEmpleado.calcularSueldoBruto().ToString();
            lblSueldoNeto.Text = miEmpleado.calcularSueldoNeto().ToString();
            lblBono.Text = miEmpleado.Bono.ToString();
            lblCalificacion.Text = miEmpleado.Calificacion;
            lblPasos.Text = miEmpleado.PasosRecorridos.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo_clase_4
{
    public class Empleado : Persona
    {
        private double sueldo;
        private double bono;
        private String calificacion;
        public event EventHandler ImpuestoHandler;

        public Empleado()
        {
            this.calificacion = "C";
            sueldo = 2000;
            bono = 100;
        }
        public Empleado(double sueldo)
        {
            this.sueldo = sueldo;
            this.calificacion = "B";
        }

        public double Sueldo
        {
            get { return sueldo; }
        }
        public String Calificacion
        {
            get { return calificacion; }
        }

        public double Bono { get => bono; set => bono = value; }

        public override void saludar()
        {
            MessageBox.Show("Hola soy un empleado");
        }


        public double calcularSueldoBruto()
        {
            double aumentoCalificacion = 0;
            if (Calificacion == "A")
            {
                aumentoCalificacion = sueldo * 0.1;
            }else if (Calificacion == "B")
            {
                aumentoCalificacion = sueldo * 0.05;
            }

            double sueldoBruto = sueldo + aumentoCalificacion + bono;
            return sueldoBruto;

            if(sueldoBruto >= 5000000)
            {
                MessageBox.Show("")
            }
        }

        public double calcularSueldoNeto()
        {
            double sueldoBruto = calcularSueldoBruto();
            double retenciones = sueldoBruto * 0.17;
            double sueldoNeto = sueldoBruto - retenciones;
            return sueldoNeto;
        }

        public void calificar(string calificacion)
        {
            this.calificacion = calificacion;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Empleados_Y_Candidatos
{
    public class Empleados : Persona
    {
        private double sueldo;
        private double bono;
        private string calificacion;

        public double Sueldo { get => sueldo;}
        public double Bono { get => bono; set => bono = value; }
        public string Calificacion { get => calificacion;}

        //constructor
        public Empleados()
        {
           
        }
        public void CalcularSueldoBruto()
        {
            
        }
        public void CalcularSueldoNeto()
        {
            
        }
        public void Calificar(string Calificacion)
        {
            this.calificacion= Calificacion;
        }

        public override void Saludar()
        {
            
        }
    }
}

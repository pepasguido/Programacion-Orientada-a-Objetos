﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Empleados_Y_Candidatos
{
    public abstract class Persona
    {
        //Atributos privados
        private string nombre;
        private string apellido;
        private int dni;
        private int pasosRecorridos;

        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public int Dni { get => dni; set => dni = value; }
        public int PasosRecorridos { get => pasosRecorridos; set => pasosRecorridos = value; }

        //metodo abstracto
        public abstract void Saludar();

        public void Caminar(int pasos)
        {
            pasos = pasos * 1;
        }
        public void Correr(int pasos)
        {
            pasos = pasos * 2;
        }
        public void Ejercicio(int pasos)
        {
            pasos = pasos * 3;
        }






    }
}

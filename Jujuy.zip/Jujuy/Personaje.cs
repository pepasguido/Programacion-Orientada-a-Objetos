﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jujuy
{
    public abstract class Personaje
    {
        private string nombre;
        protected int nivel;
        private double xp;
        protected double ataque;
        protected double defensa;
        protected double velocidad;
        private double hp;

        public string Nombre { get => nombre; set => nombre = value; }
        public int Nivel { get => nivel;}
        public double Xp { get => xp; set => xp = value; }
        public double Ataque { get => ataque;}
        public double Defensa { get => defensa;}
        public double Velocidad { get => velocidad;}
        public double Hp { get => hp; set => hp = value; }

        public abstract void RealizarEntrenaminto(int horasEntrenadas);
        public abstract void EliminarEnemigo(int nivelEnemigo);

        public void Descansar()
        {
          xp = xp - 50;
            hp = 100;
        }
        public void SubirDeNivel()
        {
            hp = 100;
            xp = 0;
            ataque++;
            defensa++;
            velocidad++;
            nivel++;
            Disparador();
        }
        public void curar()
        {
            Hp = 100;
        }
        public event EventHandler mieventHandler;

        public void Disparador()
        {
            if (mieventHandler != null)
            {
                mieventHandler(this, EventArgs.Empty);
            }
        }
    }
}

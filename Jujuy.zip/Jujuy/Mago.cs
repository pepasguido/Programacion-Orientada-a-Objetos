﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jujuy
{
    public class Mago : Personaje
    {
        public override void EliminarEnemigo(int nivelEnemigo)
        {
            Hp = Hp - (nivelEnemigo / defensa) * 2 - (nivelEnemigo / velocidad) * 2;
            Xp = Xp + nivelEnemigo * 4;
        }

        public override void RealizarEntrenaminto(int horasEntrenadas)
        {
            Xp = Xp + horasEntrenadas + (horasEntrenadas * ataque) / nivel;
            if (Xp >= 800)
            {
                SubirDeNivel();
            }
        }
        public void invocarPoderCuracion()
        {
            if(nivel>=0 && nivel <= 25)
            {
                Hp = Hp + (Hp * 0.25);
            }else if(nivel<=100 && nivel >= 26)
            {
                Hp = Hp + (Hp * 0.35);
            }
        }
        public Mago(string name)
        {
            this.Nombre = name;
            Hp = 100;
            nivel = 1;
            ataque = 5;
            velocidad = 5;
            defensa = 1;
        }
    }
}

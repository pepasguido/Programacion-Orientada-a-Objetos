﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jujuy
{
    public class Guerrero : Personaje
    {
        public override void EliminarEnemigo(int nivelEnemigo)
        {
            Hp = Hp - (nivelEnemigo / Defensa) - (nivelEnemigo * velocidad) / nivel;
            Xp = Xp + nivelEnemigo * 2;
            if (Xp >= 1000)
            {
                SubirDeNivel();
            }
        }

        public override void RealizarEntrenaminto(int horasEntrenadas)
        {
            Xp = Xp + (horasEntrenadas * Velocidad) / Nivel;
            if(Xp >= 1000)
            {
               SubirDeNivel();
            }
        }

        public Guerrero(string name)
        {
            this.Nombre = name;
            Hp = 100;
            nivel = 1;
            ataque = 2;
            velocidad = 2;
            defensa = 5;
        }
    }
}

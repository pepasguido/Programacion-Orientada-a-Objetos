﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jujuy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void eventito(object sender, EventArgs e)
        {
            MessageBox.Show("MESSI ES CAMPEON DEL MUNDO");
        }

        public void ActualizarLabels()
        {
            label6.Text =Convert.ToString(miPersonaje.Nivel);
            label7.Text =Convert.ToString(miPersonaje.Hp);
            label8.Text =Convert.ToString(miPersonaje.Ataque);
            label9.Text =Convert.ToString(miPersonaje.Defensa);
            label10.Text =Convert.ToString(miPersonaje.Velocidad);
        }
        public void Borrartxtbox()
        {
            txtHorasEntrenadas.Text = "";
            txtNivelEnemigo.Text = "";
            txtHorasEntrenadas.Text = "";


        }

        private Personaje miPersonaje = null;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true) 
            {
                miPersonaje = new Guerrero(txtNombre.Text);
                miPersonaje.mieventHandler += eventito;
                ActualizarLabels();
                Borrartxtbox();
            }
            else if (radioButton2.Checked==true)
            {
                miPersonaje = new Mago(txtNombre.Text);
                miPersonaje.mieventHandler += eventito;
                ActualizarLabels();
                Borrartxtbox();
                btnpoder.Enabled = true;
                
            }
        }

        private void btnEliminarEnemigo_Click(object sender, EventArgs e)
        {
            miPersonaje.EliminarEnemigo(Convert.ToInt32(txtNivelEnemigo.Text));
            ActualizarLabels();
            Borrartxtbox();
        }

        private void btnHorasEntrenadas_Click(object sender, EventArgs e)
        {
            miPersonaje.RealizarEntrenaminto(Convert.ToInt32(txtHorasEntrenadas.Text));
            ActualizarLabels();
            Borrartxtbox();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            miPersonaje.curar();
            ActualizarLabels();
        }
    }
}

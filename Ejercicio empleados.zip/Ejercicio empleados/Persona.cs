﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_empleados
{
    public abstract class Persona
    {
        private string nombre;
        private string apellido;
        private string dni;
        private int pasosRecorridos;

        //propiedades de lectura y escritura publicas
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Dni { get => dni; set => dni = value; }
        public int PasosRecorridos { get => pasosRecorridos; set => pasosRecorridos = value; }

        public abstract void saludar();
        
        //recibe la cantidad de pasos que va a caminar la persona
        public void caminar(int pasos)
        {
            pasosRecorridos = pasosRecorridos + pasos;
        }
        public void correr(int pasos)
        {
            pasosRecorridos = pasosRecorridos + pasos *2;
        }
        public void ejercicio(int pasos)
        {
            pasosRecorridos = pasosRecorridos + pasos * 3;
        }




    }
}

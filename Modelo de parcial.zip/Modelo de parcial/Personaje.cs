﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modelo_de_parcial
{
    public abstract class Personaje
    {
        private String nombre;
        protected int nivel;
        private double puntosDeExperiencia;
        protected double ataque;
        protected double defensa;
        protected double velocidad;
        protected double vidaActual;

        public string Nombre { get => nombre; set => nombre = value; }
        public int Nivel { get => nivel;}
        public double PuntosDeExperiencia { get => puntosDeExperiencia; set => puntosDeExperiencia = value; }
        public double Ataque { get => ataque;}
        public double Defensa { get => defensa;}
        public double Velocidad { get => velocidad;}
        public double VidaActual { get => vidaActual;}

        public abstract void RealizarEntrenamiento(int horasEntrenadas);
        public abstract void EliminarEnemigo (int nivelEnemigo);
        public void Descansar()
        {
            puntosDeExperiencia= puntosDeExperiencia- 50;
            vidaActual = 100;
        }
        public void SubirDeNivel()
        {
            vidaActual = 100;
            puntosDeExperiencia = 0;
            velocidad++;
            ataque++;
            defensa++;
            nivel++;
        }



    }
}

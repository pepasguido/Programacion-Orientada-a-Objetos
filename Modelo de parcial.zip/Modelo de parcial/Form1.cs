﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modelo_de_parcial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void ActualizarLBL()
        {
            lblNivel.Text = miPersonaje.Nivel.ToString();
            lblVida.Text = miPersonaje.VidaActual.ToString();
            lblAtaque.Text = miPersonaje.Ataque.ToString();
            lblDefensa.Text = miPersonaje.Defensa.ToString();
            lblVelocidad.Text = miPersonaje.Velocidad.ToString();

        }

       private Personaje miPersonaje = null;

        private void button1_Click(object sender, EventArgs e)
        {
            if(radioGuerrero.Checked != false || radioMago.Checked != false)
            {
                if(txtNombre.TextLength>=5){

                    if (radioGuerrero.Checked == true)
                    {
                        //crear guerrero
                        miPersonaje = new GUERRERO();
                        MessageBox.Show("CREO UN GUERRERO");
                    }
                    if (radioMago.Checked == true)
                    {
                        //crear mago
                        miPersonaje = new MAGO();
                        MessageBox.Show("CREO UN MAGO");
                    }
                }
                else
                {
                    MessageBox.Show("EL NOMBRE DEBE TENER MAS DE 5 CARACTERES");
                }
            }
            else
            {
                MessageBox.Show("SELECCIONE UNA OPCION");
            }
            txtNombre.Text = "";
            btnDescansar.Enabled = true;
            btnInvocarPoderDeCuracion.Enabled = true;
            
        }

        private void txHorasEntrenadas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void btnEntrenar_Click(object sender, EventArgs e)
        {
            if (txtHorasEntrenadas.Text != "" && Convert.ToInt32(txtHorasEntrenadas.Text)>=1)
            {
                miPersonaje.RealizarEntrenamiento(Convert.ToInt32(txtHorasEntrenadas.Text));
            }
            else
            {
                MessageBox.Show("COMPLETE LAS HORAS ENTRENADAS");
            }
            txtHorasEntrenadas.Text = "";
            ActualizarLBL();
        }

        private void txtNivelEnemigo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void btnEliminarEnemigo_Click(object sender, EventArgs e)
        {
            if (txtHorasEntrenadas.Text != "")
            {
                miPersonaje.EliminarEnemigo(Convert.ToInt32(txtNivelEnemigo.Text));
            }
            else
            {
                MessageBox.Show("COMPLETE EL NIVEL DEL ENEMIGO");
            }
            txtNivelEnemigo.Text = "";
            ActualizarLBL();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnInvocarPoderDeCuracion_Click(object sender, EventArgs e)
        {
            ((MAGO)miPersonaje).invocarPoderCuracion();
            ActualizarLBL();
        }

        private void btnDescansar_Click(object sender, EventArgs e)
        {
            ((MAGO)miPersonaje).Descansar();
            ActualizarLBL();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Modelo_de_parcial
{
    internal class GUERRERO : Personaje
    {
        public override void EliminarEnemigo(int nivelEnemigo)
        {
            vidaActual = vidaActual - (nivelEnemigo / Defensa) - (nivelEnemigo / Velocidad);

            PuntosDeExperiencia = PuntosDeExperiencia + nivelEnemigo * 2;

            if (PuntosDeExperiencia >= 1000)
            {
                SubirDeNivel();
            }
        }

        public override void RealizarEntrenamiento(int horasEntrenadas)
        {
            PuntosDeExperiencia = PuntosDeExperiencia + (horasEntrenadas * Velocidad) / Nivel;

            if (PuntosDeExperiencia >= 1000)
            {
                SubirDeNivel();
            }

        }

        public GUERRERO()
        {
            vidaActual = 100;
            nivel = 1;
            ataque = 2;
            velocidad = 2;
            defensa = 5;
        }
    }
}

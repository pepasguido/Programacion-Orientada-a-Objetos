﻿namespace Modelo_de_parcial
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioGuerrero = new System.Windows.Forms.RadioButton();
            this.radioMago = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtHorasEntrenadas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnEntrenar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNivelEnemigo = new System.Windows.Forms.TextBox();
            this.btnEliminarEnemigo = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblNivel = new System.Windows.Forms.Label();
            this.lblVelocidad = new System.Windows.Forms.Label();
            this.lblDefensa = new System.Windows.Forms.Label();
            this.lblAtaque = new System.Windows.Forms.Label();
            this.lblVida = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnDescansar = new System.Windows.Forms.Button();
            this.btnInvocarPoderDeCuracion = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioGuerrero);
            this.groupBox1.Controls.Add(this.radioMago);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtNombre);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(371, 158);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Creacion";
            // 
            // radioGuerrero
            // 
            this.radioGuerrero.AutoSize = true;
            this.radioGuerrero.Location = new System.Drawing.Point(60, 115);
            this.radioGuerrero.Name = "radioGuerrero";
            this.radioGuerrero.Size = new System.Drawing.Size(129, 24);
            this.radioGuerrero.TabIndex = 9;
            this.radioGuerrero.TabStop = true;
            this.radioGuerrero.Text = "GUERRERO";
            this.radioGuerrero.UseVisualStyleBackColor = true;
            // 
            // radioMago
            // 
            this.radioMago.AutoSize = true;
            this.radioMago.Location = new System.Drawing.Point(60, 84);
            this.radioMago.Name = "radioMago";
            this.radioMago.Size = new System.Drawing.Size(83, 24);
            this.radioMago.TabIndex = 8;
            this.radioMago.TabStop = true;
            this.radioMago.Text = "MAGO";
            this.radioMago.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(239, 29);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 29);
            this.button1.TabIndex = 7;
            this.button1.Text = "CREAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "NOMBRE:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(114, 32);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(100, 26);
            this.txtNombre.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnEliminarEnemigo);
            this.groupBox2.Controls.Add(this.txtNivelEnemigo);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(451, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(373, 148);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ENEMIGO";
            // 
            // txtHorasEntrenadas
            // 
            this.txtHorasEntrenadas.Location = new System.Drawing.Point(162, 200);
            this.txtHorasEntrenadas.Name = "txtHorasEntrenadas";
            this.txtHorasEntrenadas.Size = new System.Drawing.Size(100, 26);
            this.txtHorasEntrenadas.TabIndex = 7;
            this.txtHorasEntrenadas.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txHorasEntrenadas_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 203);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Horas Entrenadas:";
            // 
            // btnEntrenar
            // 
            this.btnEntrenar.Location = new System.Drawing.Point(278, 196);
            this.btnEntrenar.Name = "btnEntrenar";
            this.btnEntrenar.Size = new System.Drawing.Size(88, 34);
            this.btnEntrenar.TabIndex = 9;
            this.btnEntrenar.Text = "Entrenar";
            this.btnEntrenar.UseVisualStyleBackColor = true;
            this.btnEntrenar.Click += new System.EventHandler(this.btnEntrenar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Nivel Enemigo:";
            // 
            // txtNivelEnemigo
            // 
            this.txtNivelEnemigo.Location = new System.Drawing.Point(126, 28);
            this.txtNivelEnemigo.Name = "txtNivelEnemigo";
            this.txtNivelEnemigo.Size = new System.Drawing.Size(100, 26);
            this.txtNivelEnemigo.TabIndex = 11;
            this.txtNivelEnemigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNivelEnemigo_KeyPress);
            // 
            // btnEliminarEnemigo
            // 
            this.btnEliminarEnemigo.Location = new System.Drawing.Point(246, 17);
            this.btnEliminarEnemigo.Name = "btnEliminarEnemigo";
            this.btnEliminarEnemigo.Size = new System.Drawing.Size(114, 58);
            this.btnEliminarEnemigo.TabIndex = 12;
            this.btnEliminarEnemigo.Text = "Eliminar Enemigo";
            this.btnEliminarEnemigo.UseVisualStyleBackColor = true;
            this.btnEliminarEnemigo.Click += new System.EventHandler(this.btnEliminarEnemigo_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.lblVida);
            this.groupBox3.Controls.Add(this.lblAtaque);
            this.groupBox3.Controls.Add(this.lblDefensa);
            this.groupBox3.Controls.Add(this.lblVelocidad);
            this.groupBox3.Controls.Add(this.lblNivel);
            this.groupBox3.Location = new System.Drawing.Point(451, 220);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(373, 218);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "INFORMACION";
            // 
            // lblNivel
            // 
            this.lblNivel.AutoSize = true;
            this.lblNivel.Location = new System.Drawing.Point(138, 43);
            this.lblNivel.Name = "lblNivel";
            this.lblNivel.Size = new System.Drawing.Size(13, 20);
            this.lblNivel.TabIndex = 0;
            this.lblNivel.Text = ":";
            // 
            // lblVelocidad
            // 
            this.lblVelocidad.AutoSize = true;
            this.lblVelocidad.Location = new System.Drawing.Point(138, 173);
            this.lblVelocidad.Name = "lblVelocidad";
            this.lblVelocidad.Size = new System.Drawing.Size(13, 20);
            this.lblVelocidad.TabIndex = 1;
            this.lblVelocidad.Text = ":";
            this.lblVelocidad.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblDefensa
            // 
            this.lblDefensa.AutoSize = true;
            this.lblDefensa.Location = new System.Drawing.Point(138, 139);
            this.lblDefensa.Name = "lblDefensa";
            this.lblDefensa.Size = new System.Drawing.Size(13, 20);
            this.lblDefensa.TabIndex = 2;
            this.lblDefensa.Text = ":";
            // 
            // lblAtaque
            // 
            this.lblAtaque.AutoSize = true;
            this.lblAtaque.Location = new System.Drawing.Point(138, 108);
            this.lblAtaque.Name = "lblAtaque";
            this.lblAtaque.Size = new System.Drawing.Size(13, 20);
            this.lblAtaque.TabIndex = 3;
            this.lblAtaque.Text = ":";
            // 
            // lblVida
            // 
            this.lblVida.AutoSize = true;
            this.lblVida.Location = new System.Drawing.Point(139, 73);
            this.lblVida.Name = "lblVida";
            this.lblVida.Size = new System.Drawing.Size(13, 20);
            this.lblVida.TabIndex = 4;
            this.lblVida.Text = ":";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nivel:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 20);
            this.label5.TabIndex = 6;
            this.label5.Text = "Vida:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(39, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Ataque:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(39, 139);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 20);
            this.label7.TabIndex = 8;
            this.label7.Text = "Defensa:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 20);
            this.label8.TabIndex = 9;
            this.label8.Text = "Velocidad:";
            // 
            // btnDescansar
            // 
            this.btnDescansar.Enabled = false;
            this.btnDescansar.Location = new System.Drawing.Point(17, 367);
            this.btnDescansar.Name = "btnDescansar";
            this.btnDescansar.Size = new System.Drawing.Size(128, 71);
            this.btnDescansar.TabIndex = 14;
            this.btnDescansar.Text = "Descansar";
            this.btnDescansar.UseVisualStyleBackColor = true;
            this.btnDescansar.Click += new System.EventHandler(this.btnDescansar_Click);
            // 
            // btnInvocarPoderDeCuracion
            // 
            this.btnInvocarPoderDeCuracion.Enabled = false;
            this.btnInvocarPoderDeCuracion.Location = new System.Drawing.Point(306, 359);
            this.btnInvocarPoderDeCuracion.Name = "btnInvocarPoderDeCuracion";
            this.btnInvocarPoderDeCuracion.Size = new System.Drawing.Size(139, 71);
            this.btnInvocarPoderDeCuracion.TabIndex = 15;
            this.btnInvocarPoderDeCuracion.Text = "Invocar Poder de Curacion";
            this.btnInvocarPoderDeCuracion.UseVisualStyleBackColor = true;
            this.btnInvocarPoderDeCuracion.Click += new System.EventHandler(this.btnInvocarPoderDeCuracion_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 450);
            this.Controls.Add(this.btnInvocarPoderDeCuracion);
            this.Controls.Add(this.btnDescansar);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnEntrenar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtHorasEntrenadas);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioGuerrero;
        private System.Windows.Forms.RadioButton radioMago;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtHorasEntrenadas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnEntrenar;
        private System.Windows.Forms.Button btnEliminarEnemigo;
        private System.Windows.Forms.TextBox txtNivelEnemigo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblVida;
        private System.Windows.Forms.Label lblAtaque;
        private System.Windows.Forms.Label lblDefensa;
        private System.Windows.Forms.Label lblVelocidad;
        private System.Windows.Forms.Label lblNivel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnDescansar;
        private System.Windows.Forms.Button btnInvocarPoderDeCuracion;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelo_de_parcial
{
    internal class MAGO : Personaje
    {
        public override void EliminarEnemigo(int nivelEnemigo)
        {
            vidaActual = vidaActual - (nivelEnemigo / defensa) * 2 - (nivelEnemigo / velocidad) * 2;
            PuntosDeExperiencia = PuntosDeExperiencia + nivelEnemigo * 4;
            if (PuntosDeExperiencia >= 800)
            {
                SubirDeNivel();
            }
        }

        public override void RealizarEntrenamiento(int horasEntrenadas)
        {
            PuntosDeExperiencia = PuntosDeExperiencia + horasEntrenadas + (horasEntrenadas * ataque) / nivel;
            if (PuntosDeExperiencia >= 800)
            {
                SubirDeNivel();
            }
        }
        public void invocarPoderCuracion()
        {
            if(nivel<=25 && nivel >= 0)
            {
                vidaActual = vidaActual + (vidaActual * 0.25);
            }else if(nivel<100 && nivel >= 26)
            {
                vidaActual = vidaActual + (vidaActual * 0.35);
            }
        }
        public MAGO()
        {
            vidaActual = 100;
            nivel = 1;
            ataque = 5;
            velocidad = 5;
            defensa = 1;
        }

    }
}

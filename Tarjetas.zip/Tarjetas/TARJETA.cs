﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace Tarjetas
{
    public abstract class TARJETA
    {
        private Int64 numeroTarjeta;
        private string nombreApellidoTarjeta;
        protected int codigoSeguridad;

        public Int64 NumeroTarjeta { get => numeroTarjeta; set => numeroTarjeta = value; }
        public string NombreApellidoTarjeta { get => nombreApellidoTarjeta; set => nombreApellidoTarjeta = value; }
        public int CodigoSeguridad { set => codigoSeguridad = value; }

        public abstract double pagar(double montoAPagar, int numeroTarjeta, int codigoSeguridad);

        public event EventHandler ImpuestoTrajetaHandler;

        public void DispararEvento()
        {
            if (ImpuestoTrajetaHandler != null)
            {
                ImpuestoTrajetaHandler(this, EventArgs.Empty);
            }
            else
            {
                MessageBox.Show("No aplica el evento");
            }
        }
    }
}

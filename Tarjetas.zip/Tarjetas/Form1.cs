﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tarjetas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        TARJETA miTarjeta = null;
        public void ImpuestoTrajeta(object sender, EventArgs e)
        {
            MessageBox.Show("PAGA IMPUESTO BURRO");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text== "Tarjeta black")
            {
                miTarjeta = new Tarjeta_Black(Convert.ToInt32(txtNroTarjeta.Text),Convert.ToString(txtNombreyApellido.Text),Convert.ToInt16(txtCodseguridad.Text));
                double montoPagar = ((Tarjeta_Black)miTarjeta).pagar(Convert.ToDouble(txtMontoPagar.Text),Convert.ToInt32(txtNroTarjeta.Text),Convert.ToInt16(txtCodseguridad.Text));
                MessageBox.Show("El monto Total a pagar de su tarjeta Black es: "+montoPagar);
                miTarjeta.ImpuestoTrajetaHandler += ImpuestoTrajeta;
               
            }else if (comboBox1.Text== "Tarjeta Clasica")
            {
                miTarjeta = new Tarjeta_Clasica(Convert.ToInt32(txtNroTarjeta.Text), Convert.ToString(txtNombreyApellido.Text), Convert.ToInt16(txtCodseguridad.Text));
                double montoPagar = ((Tarjeta_Clasica)miTarjeta).pagar(Convert.ToDouble(txtMontoPagar.Text), Convert.ToInt32(txtNroTarjeta.Text), Convert.ToInt16(txtCodseguridad.Text));
                
                MessageBox.Show("El monto Total a pagar de su tarjeta Clasica es: " + montoPagar);
            }
            else if (comboBox1.Text=="Tarjeta Platinum")
            {
                miTarjeta = new Tarjeta_Platinum(Convert.ToInt32(txtNroTarjeta.Text), Convert.ToString(txtNombreyApellido.Text), Convert.ToInt16(txtCodseguridad.Text));
                double montoPagar = ((Tarjeta_Platinum)miTarjeta).pagar(Convert.ToDouble(txtMontoPagar.Text), Convert.ToInt32(txtNroTarjeta.Text), Convert.ToInt16(txtCodseguridad.Text));
                MessageBox.Show("El monto Total a pagar de su tarjeta Platinum es: " + montoPagar);
            }
        }
    }
}

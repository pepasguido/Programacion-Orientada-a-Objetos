﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tarjetas
{
    public class Tarjeta_Platinum : TARJETA
    {

        public override double pagar(double montoAPagar, int numeroTarjeta, int codigoSeguridad)
        {
            if (montoAPagar >= 0)
            {
                if (this.NumeroTarjeta != numeroTarjeta && this.codigoSeguridad != codigoSeguridad)
                {
                    MessageBox.Show("Los datos ingresados no coinciden");
                    return 0;
                }
                else
                {
                    return montoAPagar * 0.98;
                }
            }
            else
            {
                MessageBox.Show("Ingrese un valor valido");
                return 0;
            }
        }
        //Constructor
        public Tarjeta_Platinum(int numeroTarjeta, string nombreApellidoTarjeta, int codigoSeguridad)
        {
            this.NumeroTarjeta = numeroTarjeta;
            this.NombreApellidoTarjeta = nombreApellidoTarjeta;
            this.CodigoSeguridad = codigoSeguridad;
        }
        public event EventHandler ImpuestoTrajetaHandler;

        public void DispararEvento()
        {
            if (ImpuestoTrajetaHandler != null)
            {
                ImpuestoTrajetaHandler(this, EventArgs.Empty);
            }
            else
            {
                MessageBox.Show("No aplica el evento");
            }
        }
    }
}

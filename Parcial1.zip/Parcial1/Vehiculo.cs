﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial1
{
    public abstract class Vehiculo
    {
        protected string modelo;
        protected string marca;
        protected double capacidadTanque;
        private double capacidadActualDelTanque;
        protected double consumoKmPorLitro;
        private double kmRecorridos;

        public string Modelo { get => modelo;}
        public string Marca { get => marca;}
        public double CapacidadTanque { get => capacidadTanque;}
        public double CapacidadActualDelTanque { get => capacidadActualDelTanque; set => capacidadActualDelTanque = value; }
        public double ConsumoKmPorLitro { get => consumoKmPorLitro;}
        public double KmRecorridos { get => kmRecorridos; set => kmRecorridos = value; }

        public abstract string SimularViaje(double kmRecorridos1);

        public abstract void CargarCombustible();




    }
}

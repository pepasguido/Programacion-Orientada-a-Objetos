﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parcial1
{
    public class AutoNafta : Vehiculo
    {
        public override void CargarCombustible()
        {
            throw new NotImplementedException();
        }

        public override string SimularViaje(double kmRecorridos1)
        {
            throw new NotImplementedException();
        }

        public AutoNafta(string Modelito, string Marquita, double capacidita, double Consumito, double Kilometritos)
        {
            this.modelo = Modelito ;
            this.marca = Marquita;
            this.capacidadTanque = capacidita;
            this.consumoKmPorLitro = Consumito;
            this.KmRecorridos = Kilometritos;
            CapacidadActualDelTanque = capacidadTanque;
        }
        public void SimularViaje()
        {
            

        }

    }
}

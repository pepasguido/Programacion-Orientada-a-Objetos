﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public abstract class Personaje
    {
        //La que son solo lectura ponele protected
        private string nombre;
        protected int nivel;
        private double xp;
        protected double ataque;
        protected double velocidad;
        protected double hp;
        protected double defensa;

        public string Nombre { get => nombre; set => nombre = value; }
        public int Nivel { get => nivel;}
        public double Xp { get => xp; set => xp = value; }
        public double Ataque { get => ataque;}
        public double Velocidad { get => velocidad;}
        public double Hp { get => hp; set => hp = value; }
        public double Defensa { get => defensa;}

        //void no retorna nada
        //si el metodo es abstracto va con ;
        public abstract void RealizarEntrenamiento(int horasEntrenadas);
        public abstract void EliminarEnemigo(int nivelEnemigo);
        public void Descansar()
        {
            xp = xp - 50;
            hp = 100;
        }
        public void SubirNivel()
        {
            hp = 100;
            xp = 0;
            ataque++;
            defensa++;
            velocidad++;
            nivel++;
            //disparador
            Disparador();
        }

        //Evento
        //definir evento
        public event EventHandler SubiodenivelHandler;

        //Disparador del evento
        public void Disparador()
        {
            //si el evento exite
            if(SubiodenivelHandler != null)
            {
                //Acordate tontito es adenro del disparador del evento
                SubiodenivelHandler(this, EventArgs.Empty);
            }

        }

        public event EventHandler VidaBajaHandler;

        public void disparavida()
        {
            if(VidaBajaHandler != null)
            {
                VidaBajaHandler(this, EventArgs.Empty);
            }
           
        }

    }
}

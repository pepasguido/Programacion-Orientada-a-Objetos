﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnGuerrero = new System.Windows.Forms.Button();
            this.btnMago = new System.Windows.Forms.Button();
            this.txtHorasEntrenadas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtNivelEnemigo = new System.Windows.Forms.TextBox();
            this.btnEliminarEnemigo = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblNivel = new System.Windows.Forms.Label();
            this.lblVida = new System.Windows.Forms.Label();
            this.lblAtaque = new System.Windows.Forms.Label();
            this.lblDefensa = new System.Windows.Forms.Label();
            this.lblVelocidad = new System.Windows.Forms.Label();
            this.btnDescansar = new System.Windows.Forms.Button();
            this.btnPoderCuracion = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(89, 59);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(100, 26);
            this.txtNombre.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // btnGuerrero
            // 
            this.btnGuerrero.Location = new System.Drawing.Point(195, 12);
            this.btnGuerrero.Name = "btnGuerrero";
            this.btnGuerrero.Size = new System.Drawing.Size(146, 47);
            this.btnGuerrero.TabIndex = 2;
            this.btnGuerrero.Text = "Crear Guerreo";
            this.btnGuerrero.UseVisualStyleBackColor = true;
            this.btnGuerrero.Click += new System.EventHandler(this.btnGuerrero_Click);
            // 
            // btnMago
            // 
            this.btnMago.Location = new System.Drawing.Point(195, 78);
            this.btnMago.Name = "btnMago";
            this.btnMago.Size = new System.Drawing.Size(146, 47);
            this.btnMago.TabIndex = 3;
            this.btnMago.Text = "Crear Mago";
            this.btnMago.UseVisualStyleBackColor = true;
            this.btnMago.Click += new System.EventHandler(this.btnMago_Click);
            // 
            // txtHorasEntrenadas
            // 
            this.txtHorasEntrenadas.Location = new System.Drawing.Point(532, 33);
            this.txtHorasEntrenadas.Name = "txtHorasEntrenadas";
            this.txtHorasEntrenadas.Size = new System.Drawing.Size(100, 26);
            this.txtHorasEntrenadas.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(383, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Horas Entrenadas:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(532, 78);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 37);
            this.button1.TabIndex = 6;
            this.button1.Text = "Entrenar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtNivelEnemigo
            // 
            this.txtNivelEnemigo.Location = new System.Drawing.Point(132, 222);
            this.txtNivelEnemigo.Name = "txtNivelEnemigo";
            this.txtNivelEnemigo.Size = new System.Drawing.Size(100, 26);
            this.txtNivelEnemigo.TabIndex = 7;
            // 
            // btnEliminarEnemigo
            // 
            this.btnEliminarEnemigo.Location = new System.Drawing.Point(132, 254);
            this.btnEliminarEnemigo.Name = "btnEliminarEnemigo";
            this.btnEliminarEnemigo.Size = new System.Drawing.Size(88, 59);
            this.btnEliminarEnemigo.TabIndex = 8;
            this.btnEliminarEnemigo.Text = "Eliminar enemigo";
            this.btnEliminarEnemigo.UseVisualStyleBackColor = true;
            this.btnEliminarEnemigo.Click += new System.EventHandler(this.btnEliminarEnemigo_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Nivel Enemigo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(132, 356);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Nivel:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(224, 356);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "Vida:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(312, 356);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "Ataque:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(383, 356);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Defensa:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(475, 356);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Velocidad:";
            // 
            // lblNivel
            // 
            this.lblNivel.AutoSize = true;
            this.lblNivel.Location = new System.Drawing.Point(136, 401);
            this.lblNivel.Name = "lblNivel";
            this.lblNivel.Size = new System.Drawing.Size(51, 20);
            this.lblNivel.TabIndex = 15;
            this.lblNivel.Text = "label9";
            // 
            // lblVida
            // 
            this.lblVida.AutoSize = true;
            this.lblVida.Location = new System.Drawing.Point(209, 401);
            this.lblVida.Name = "lblVida";
            this.lblVida.Size = new System.Drawing.Size(60, 20);
            this.lblVida.TabIndex = 16;
            this.lblVida.Text = "label10";
            // 
            // lblAtaque
            // 
            this.lblAtaque.AutoSize = true;
            this.lblAtaque.Location = new System.Drawing.Point(317, 401);
            this.lblAtaque.Name = "lblAtaque";
            this.lblAtaque.Size = new System.Drawing.Size(60, 20);
            this.lblAtaque.TabIndex = 17;
            this.lblAtaque.Text = "label11";
            // 
            // lblDefensa
            // 
            this.lblDefensa.AutoSize = true;
            this.lblDefensa.Location = new System.Drawing.Point(397, 401);
            this.lblDefensa.Name = "lblDefensa";
            this.lblDefensa.Size = new System.Drawing.Size(60, 20);
            this.lblDefensa.TabIndex = 18;
            this.lblDefensa.Text = "label12";
            // 
            // lblVelocidad
            // 
            this.lblVelocidad.AutoSize = true;
            this.lblVelocidad.Location = new System.Drawing.Point(498, 401);
            this.lblVelocidad.Name = "lblVelocidad";
            this.lblVelocidad.Size = new System.Drawing.Size(60, 20);
            this.lblVelocidad.TabIndex = 19;
            this.lblVelocidad.Text = "label13";
            // 
            // btnDescansar
            // 
            this.btnDescansar.Location = new System.Drawing.Point(293, 275);
            this.btnDescansar.Name = "btnDescansar";
            this.btnDescansar.Size = new System.Drawing.Size(164, 51);
            this.btnDescansar.TabIndex = 20;
            this.btnDescansar.Text = "Descansar";
            this.btnDescansar.UseVisualStyleBackColor = true;
            this.btnDescansar.Click += new System.EventHandler(this.btnDescansar_Click);
            // 
            // btnPoderCuracion
            // 
            this.btnPoderCuracion.Enabled = false;
            this.btnPoderCuracion.Location = new System.Drawing.Point(293, 218);
            this.btnPoderCuracion.Name = "btnPoderCuracion";
            this.btnPoderCuracion.Size = new System.Drawing.Size(164, 51);
            this.btnPoderCuracion.TabIndex = 21;
            this.btnPoderCuracion.Text = "Invocar Curacion";
            this.btnPoderCuracion.UseVisualStyleBackColor = true;
            this.btnPoderCuracion.Click += new System.EventHandler(this.btnPoderCuracion_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 450);
            this.Controls.Add(this.btnPoderCuracion);
            this.Controls.Add(this.btnDescansar);
            this.Controls.Add(this.lblVelocidad);
            this.Controls.Add(this.lblDefensa);
            this.Controls.Add(this.lblAtaque);
            this.Controls.Add(this.lblVida);
            this.Controls.Add(this.lblNivel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnEliminarEnemigo);
            this.Controls.Add(this.txtNivelEnemigo);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtHorasEntrenadas);
            this.Controls.Add(this.btnMago);
            this.Controls.Add(this.btnGuerrero);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNombre);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGuerrero;
        private System.Windows.Forms.Button btnMago;
        private System.Windows.Forms.TextBox txtHorasEntrenadas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtNivelEnemigo;
        private System.Windows.Forms.Button btnEliminarEnemigo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblNivel;
        private System.Windows.Forms.Label lblVida;
        private System.Windows.Forms.Label lblAtaque;
        private System.Windows.Forms.Label lblDefensa;
        private System.Windows.Forms.Label lblVelocidad;
        private System.Windows.Forms.Button btnDescansar;
        private System.Windows.Forms.Button btnPoderCuracion;
    }
}


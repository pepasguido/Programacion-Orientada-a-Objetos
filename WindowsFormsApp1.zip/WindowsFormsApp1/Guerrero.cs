﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Guerrero : Personaje
    {
        public override void EliminarEnemigo(int nivelEnemigo)
        {
            //USAR EL DE MAYUSCULA
            Hp = Hp - (nivelEnemigo / Defensa) - (nivelEnemigo / Velocidad);
            Xp = Xp + nivelEnemigo * 2;
            if (Xp >= 1000)
            {
                SubirNivel();
            }
            if(Hp <= 20)
            {
                disparavida();
            }
        }

        public override void RealizarEntrenamiento(int horasEntrenadas)
        {
            //USAR EL DE MAYUSCULA
            Xp = Xp + (horasEntrenadas * Velocidad) / Nivel;
            if (Xp >= 1000)
            {
                SubirNivel();
            }
        }

        //constructor
        //ctor
        public Guerrero(string nombre)
        {   //usar minuscula para acceder a los parametros
            //chequear lo de el this????????????????????
            hp = 100;
            nivel = 1;
            ataque = 2;
            velocidad = 2;
            defensa = 5;
            this.Nombre = nombre;
        }


    }
}

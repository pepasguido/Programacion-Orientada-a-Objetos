﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //Acordate boludo eh
        //mi personaje = null ates que todo
        private Personaje miPersonaje = null;
        public Form1()
        {
            InitializeComponent();
        }

        //definir lo que hace el evento
        //acordate del object sender
        private void Subio(object sender, EventArgs e)
        {
            MessageBox.Show("Subio de nivel", "Alerta",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
        }
        private void vidaBaja(object sender, EventArgs e)
        {
            MessageBox.Show("VIDA BAJA");
        }
        public void ActualizarLabels()
        {
            lblAtaque.Text =Convert.ToString(miPersonaje.Ataque);
            lblDefensa.Text =Convert.ToString(miPersonaje.Defensa);
            lblNivel.Text =Convert.ToString(miPersonaje.Nivel);
            lblVelocidad.Text =Convert.ToString(miPersonaje.Velocidad);
            lblVida.Text = Convert.ToString(miPersonaje.Hp);
        }
        
        private void btnGuerrero_Click(object sender, EventArgs e)
        {
            //NO TE OLVIDES DEL LENGTH
            if(txtNombre.Text != "" && txtNombre.Text.Length>=5)
            {
                miPersonaje = new Guerrero(txtNombre.Text);
            }
            ActualizarLabels();
            btnPoderCuracion.Enabled = false;
            //suscribimos al eveto
            //primero llamas al evento += a lo que tiene que hacer
            miPersonaje.SubiodenivelHandler += Subio;
            miPersonaje.VidaBajaHandler += vidaBaja;

        }

        private void btnMago_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text != "" && txtNombre.Text.Length >= 5)
            {
                miPersonaje = new Mago(txtNombre.Text);
            }
            ActualizarLabels();
            btnPoderCuracion.Enabled = true;
            //suscribimos al eveto
            //primero llamas al evento += a lo que tiene que hacer
            miPersonaje.SubiodenivelHandler += Subio;
            miPersonaje.VidaBajaHandler += vidaBaja;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtHorasEntrenadas.Text != "" && txtHorasEntrenadas.Text.Length >= 1)
            {
                //ASI SE LLAMA AL ENTRENAMINETO
                miPersonaje.RealizarEntrenamiento(Convert.ToInt32(txtHorasEntrenadas.Text));
            }
            ActualizarLabels();
           
        }

        private void btnEliminarEnemigo_Click(object sender, EventArgs e)
        {
            if (txtNivelEnemigo.Text != "" && txtNivelEnemigo.Text.Length >= 1)
            {
                //ASI SE LLAMA AL ENTRENAMINETO
                miPersonaje.EliminarEnemigo(Convert.ToInt32(txtNivelEnemigo.Text));
            }
            ActualizarLabels();
        }

        private void btnPoderCuracion_Click(object sender, EventArgs e)
        {
            ((Mago)miPersonaje).InvocarCuracion();
            ActualizarLabels();
        }

        private void btnDescansar_Click(object sender, EventArgs e)
        {
            miPersonaje.Descansar();
            ActualizarLabels();
        }
    }
}

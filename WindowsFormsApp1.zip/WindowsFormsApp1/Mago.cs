﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class Mago : Personaje
    {
        public override void EliminarEnemigo(int nivelEnemigo)
        {
            //usar Mayusculas
            Hp = Hp - (nivelEnemigo / Defensa) * 2 - (nivelEnemigo / Velocidad) * 2;
            Xp = Xp + nivelEnemigo * 4;
            if (Xp >= 800)
            {
                SubirNivel();
            }
            if (Hp <= 20)
            {
                disparavida();
            }
        }

        public override void RealizarEntrenamiento(int horasEntrenadas)
        {
            //usar Mayusculas
            Xp = Xp + horasEntrenadas + (horasEntrenadas * Ataque) / Nivel;
            if (Xp >= 800)
            {
                SubirNivel();
            }
        }

        public void InvocarCuracion()
        {
            if(Nivel>=0 && Nivel <= 25)
            {
                Hp = Hp + (Hp * 0.25);
            }else if(Nivel<=100 && Nivel >= 26)
            {
                Hp = Hp + (Hp * 0.35);
            }
        }
        public Mago(string nombre)
        {
            //usar minusculas
            hp = 100;
            nivel = 1;
            ataque = 5;
            velocidad = 5;
            defensa = 1;
            //Setear nombre del personaje
            this.Nombre = nombre;
        }

    }
}
